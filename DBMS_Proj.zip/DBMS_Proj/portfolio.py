import ttkbootstrap as tb
from ttkbootstrap.constants import *
from db_config import get_connection
from tkinter import messagebox
import mysql.connector

def open_portfolio_window(username, view="portfolio"):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        win = tb.Toplevel()
        win.title(
            f"{'All Portfolios' if username == 'all' else username}'s {'Portfolio' if view == 'portfolio' else 'Transactions'}")
        win.geometry("1100x700")

        # Summary frame
        summary_frame = tb.Frame(win)
        summary_frame.pack(fill="x", padx=10, pady=10)

        if username == "all":  # Broker view
            # Get summary stats
            cursor.execute("SELECT COUNT(DISTINCT BuyerId) FROM Portfolio")
            investor_count = cursor.fetchone()[0]

            cursor.execute("SELECT SUM(Quantity * PurchasePrice) FROM Portfolio")
            total_investment = cursor.fetchone()[0] or 0

            cursor.execute(
                "SELECT SUM(Quantity * (s.Price - p.PurchasePrice)) FROM Portfolio p JOIN Stocks s ON p.StockId = s.StockId")
            total_pl = cursor.fetchone()[0] or 0

            cursor.execute("SELECT SUM(Amount) FROM Dividend")
            total_dividends = cursor.fetchone()[0] or 0

            tb.Label(summary_frame, text=f"Investors: {investor_count}", font=("Helvetica", 10)).pack(side="left",
                                                                                                      padx=10)
            tb.Label(summary_frame, text=f"Total Investment: ₹{total_investment:,.2f}", font=("Helvetica", 10)).pack(
                side="left", padx=10)
            tb.Label(summary_frame, text=f"Total P/L: ₹{total_pl:,.2f}",
                     font=("Helvetica", 10), foreground="green" if total_pl >= 0 else "red").pack(side="left", padx=10)
            tb.Label(summary_frame, text=f"Total Dividends: ₹{total_dividends:,.2f}", font=("Helvetica", 10)).pack(
                side="left", padx=10)

            if view == "portfolio":
                cursor.execute("""
                    SELECT b.Name, s.StockId, s.StockName, p.Quantity, 
                           p.PurchasePrice, s.Price,
                           (p.Quantity * p.PurchasePrice) AS Investment,
                           (p.Quantity * (s.Price - p.PurchasePrice)) AS ProfitLoss
                    FROM Portfolio p
                    JOIN Buyer b ON p.BuyerId = b.BuyerId
                    JOIN Stocks s ON p.StockId = s.StockId
                    ORDER BY b.Name, s.StockId
                """)

                tree = tb.Treeview(win, columns=("buyer", "id", "stock", "qty", "buy", "current", "invest", "profit"),
                                   show="headings")
                tree.heading("buyer", text="Buyer")
                tree.heading("id", text="Stock ID")
                tree.heading("stock", text="Stock")
                tree.heading("qty", text="Qty")
                tree.heading("buy", text="Buy Price")
                tree.heading("current", text="Current Price")
                tree.heading("invest", text="Investment")
                tree.heading("profit", text="P/L")

                tree.column("buyer", width=120)
                tree.column("id", width=80)
                tree.column("stock", width=150)
                tree.column("qty", width=60)
                tree.column("buy", width=100)
                tree.column("current", width=100)
                tree.column("invest", width=100)
                tree.column("profit", width=100)

            else:  # Transactions view
                cursor.execute("""
                    SELECT t.TransactionId, b.Name, s.StockId, s.StockName, 
                           t.TransactionType, t.Quantity, t.Price, 
                           (t.Quantity * t.Price) AS Amount,
                           t.TransactionDate
                    FROM Transactions t
                    JOIN Buyer b ON t.BuyerId = b.BuyerId
                    JOIN Stocks s ON t.StockId = s.StockId
                    ORDER BY t.TransactionDate DESC
                    LIMIT 100
                """)

                tree = tb.Treeview(win, columns=("id", "buyer", "stockid", "stock", "type", "qty", "price", "amount",
                                                 "date"), show="headings")
                tree.heading("id", text="Txn ID")
                tree.heading("buyer", text="Buyer")
                tree.heading("stockid", text="Stock ID")
                tree.heading("stock", text="Stock")
                tree.heading("type", text="Type")
                tree.heading("qty", text="Qty")
                tree.heading("price", text="Price")
                tree.heading("amount", text="Amount")
                tree.heading("date", text="Date")

                tree.column("id", width=60)
                tree.column("buyer", width=100)
                tree.column("stockid", width=70)
                tree.column("stock", width=120)
                tree.column("type", width=70)
                tree.column("qty", width=60)
                tree.column("price", width=80)
                tree.column("amount", width=90)
                tree.column("date", width=120)

        else:  # Buyer view
            cursor.execute("SELECT BuyerId FROM Buyer WHERE Name = %s", (username,))
            buyer_result = cursor.fetchone()
            if buyer_result is None:
                messagebox.showerror("Error", "Buyer record not found")
                return
            buyer_id = buyer_result[0]

            # Get buyer stats
            cursor.execute("""
                SELECT SUM(p.Quantity * p.PurchasePrice), 
                       SUM(p.Quantity * (s.Price - p.PurchasePrice)),
                       SUM(d.Amount),
                       b.Capital
                FROM Portfolio p
                JOIN Stocks s ON p.StockId = s.StockId
                LEFT JOIN Dividend d ON d.BuyerId = p.BuyerId
                JOIN Buyer b ON p.BuyerId = b.BuyerId
                WHERE p.BuyerId = %s
            """, (buyer_id,))
            investment, profit_loss, dividends, capital = cursor.fetchone()

            investment = investment or 0
            profit_loss = profit_loss or 0
            dividends = dividends or 0
            capital = capital or 0

            tb.Label(summary_frame, text=f"Total Investment: ₹{investment:,.2f}", font=("Helvetica", 10)).pack(
                side="left", padx=10)
            tb.Label(summary_frame, text=f"Profit/Loss: ₹{profit_loss:,.2f}",
                     font=("Helvetica", 10), foreground="green" if profit_loss >= 0 else "red").pack(side="left",
                                                                                                     padx=10)
            tb.Label(summary_frame, text=f"Dividends: ₹{dividends:,.2f}", font=("Helvetica", 10)).pack(side="left",
                                                                                                       padx=10)
            tb.Label(summary_frame, text=f"Available Capital: ₹{capital:,.2f}", font=("Helvetica", 10)).pack(
                side="left", padx=10)

            if view == "portfolio":
                cursor.execute("""
                    SELECT s.StockId, s.StockName, p.Quantity, 
                           p.PurchasePrice, s.Price,
                           (p.Quantity * p.PurchasePrice) AS Investment,
                           (p.Quantity * (s.Price - p.PurchasePrice)) AS ProfitLoss
                    FROM Portfolio p
                    JOIN Stocks s ON p.StockId = s.StockId
                    WHERE p.BuyerId = %s
                    ORDER BY s.StockId
                """, (buyer_id,))

                tree = tb.Treeview(win, columns=("id", "stock", "qty", "buy", "current", "invest", "profit"),
                                   show="headings")
                tree.heading("id", text="Stock ID")
                tree.heading("stock", text="Stock")
                tree.heading("qty", text="Qty")
                tree.heading("buy", text="Buy Price")
                tree.heading("current", text="Current Price")
                tree.heading("invest", text="Investment")
                tree.heading("profit", text="P/L")

                tree.column("id", width=80)
                tree.column("stock", width=150)
                tree.column("qty", width=60)
                tree.column("buy", width=100)
                tree.column("current", width=100)
                tree.column("invest", width=100)
                tree.column("profit", width=100)

            else:  # Transactions view
                cursor.execute("""
                    SELECT t.TransactionId, s.StockId, s.StockName, 
                           t.TransactionType, t.Quantity, t.Price, 
                           (t.Quantity * t.Price) AS Amount,
                           t.TransactionDate
                    FROM Transactions t
                    JOIN Stocks s ON t.StockId = s.StockId
                    WHERE t.BuyerId = %s
                    ORDER BY t.TransactionDate DESC
                """, (buyer_id,))

                tree = tb.Treeview(win, columns=("id", "stockid", "stock", "type", "qty", "price", "amount", "date"),
                                   show="headings")
                tree.heading("id", text="Txn ID")
                tree.heading("stockid", text="Stock ID")
                tree.heading("stock", text="Stock")
                tree.heading("type", text="Type")
                tree.heading("qty", text="Qty")
                tree.heading("price", text="Price")
                tree.heading("amount", text="Amount")
                tree.heading("date", text="Date")

                tree.column("id", width=60)
                tree.column("stockid", width=70)
                tree.column("stock", width=120)
                tree.column("type", width=70)
                tree.column("qty", width=60)
                tree.column("price", width=80)
                tree.column("amount", width=90)
                tree.column("date", width=120)

        # Insert data into treeview
        for row in cursor.fetchall():
            tree.insert("", "end", values=row)

        # Add scrollbar
        scrollbar = tb.Scrollbar(win, orient="vertical", command=tree.yview)
        scrollbar.pack(side="right", fill="y")
        tree.configure(yscrollcommand=scrollbar.set)

        tree.pack(fill="both", expand=True, padx=10, pady=10)

        # View toggle button
        if username != "all":  # Only show toggle for individual buyers
            if view == "portfolio":
                tb.Button(win, text="View Transactions",
                          command=lambda: [win.destroy(), open_portfolio_window(username, "transactions")],
                          bootstyle=INFO).pack(pady=10)
            else:
                tb.Button(win, text="View Portfolio",
                          command=lambda: [win.destroy(), open_portfolio_window(username, "portfolio")],
                          bootstyle=INFO).pack(pady=10)

        tb.Button(win, text="Close", command=win.destroy, bootstyle=DANGER).pack(pady=10)

    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", str(err))
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()
